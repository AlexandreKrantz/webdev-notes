https://cs3110.github.io/textbook/cover.html
https://dev.realworldocaml.org/toc.html
https://fall2022-comp302.cs.mcgill.ca/
https://www.ocaml.org/books
[Eric Normand - YouTube](https://www.youtube.com/channel/UC2riBMG3qf1Di20ouRc76BA/featured)
https://ocaml.org/problems
https://blog.nullspace.io/beginners-guide-to-ocaml-beginners-guides.html

